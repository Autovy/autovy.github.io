package com.example.jpa;

import com.example.jpa.controller.StudentController;
import com.example.jpa.dao.StudentDAO;
import com.example.jpa.pojo.Student;
import com.example.jpa.service.StudentServicempl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
public class BTest {

    // 测试controller层
    MockMvc mockMvc;
    @Autowired
    WebApplicationContext context;



    @Before
    public void setUp() throws Exception{
        System.out.println(context);
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

   @Test
    public void get() throws Exception{
        mockMvc.perform(MockMvcRequestBuilders.get("/list").accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(MockMvcResultHandlers.print())
                .andReturn();
    }

    // 测试Dao层
    @Autowired
    StudentDAO dao;

    @Test
    public void test(){

        List<Student> students = dao.findAll();
        for(Student student : students){
            System.out.println(student.getName());
        }

    }

    // 测试service层
    @Autowired
    StudentServicempl studentServicempl;

    @Test
    public void test2(){

        List<Student> students = studentServicempl.listAll();
        for(Student student : students){
            System.out.println(student.getName());
        }
    }


}
