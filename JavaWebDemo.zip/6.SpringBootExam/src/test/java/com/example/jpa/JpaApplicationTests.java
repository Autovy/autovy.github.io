package com.example.jpa;

import com.example.jpa.controller.StudentController;
import com.example.jpa.dao.StudentDAO;
import com.example.jpa.pojo.Student;
import com.example.jpa.service.StudentServicempl;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@SpringBootTest
class JpaApplicationTests {


}
