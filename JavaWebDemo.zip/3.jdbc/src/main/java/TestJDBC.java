import java.sql.*;

public class TestJDBC {

    public static void main(String[] args) {

        try{
            // 导入数据库驱动包
            Class.forName("com.mysql.jdbc.Driver");

            // 建立与数据库的连接
            // 数据库名称， 账号，密码
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "test", "123456");

            // 创建Statement，用于执行sql语句
            Statement s = c.createStatement();

            // 编写sql语句
            String sql  = "select * from student";

            // 执行sql语句，并返回结果
            ResultSet res = s.executeQuery(sql);

            // 处理返回结果
            while(res.next()){

                int id = res.getInt("id");
                String name = res.getString("name");

                System.out.printf("%d.%s\n", id, name);

            }


        }
        // 捕捉数据库加载异常
        catch (ClassNotFoundException e){
            e.printStackTrace();
        }
        // 捕捉数据库连接异常
        catch (SQLException e){
            e.printStackTrace();
        }

    }

}
