// 一般将一个数据表抽象为一个类
public class Student {

    // 将表中的字段作为类的属性
    public int id;
    public String name;
    public int age;

}
