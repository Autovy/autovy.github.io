package com.test.service;

import com.test.client.ProductClientFeign;
import com.test.pojo.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    ProductClientFeign productClientFeign;

    // 服务类的数据从ProductClientRibbon（客户端）中获取
    public List<Product> list(){
        return productClientFeign.list();
    }

}
