package com.test.client;

import com.test.pojo.Product;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

// 实现了 ProductClientFeign 接口，并提供了 list() 方法
@Component
public class ProductClientFeignHystrix implements  ProductClientFeign {

    public List<Product> list(){
        List<Product> res = new ArrayList<>();
        res.add(new Product(0, "产品数据微服务不可用", 0));
        return res;
    }


}
