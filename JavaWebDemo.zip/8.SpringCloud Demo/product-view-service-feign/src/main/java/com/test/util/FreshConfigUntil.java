package com.test.util;

import cn.hutool.http.HttpUtil;

import java.util.HashMap;

//使用 post 的方式访问 http://localhost:8012/actuator/bus-refresh 地址
public class FreshConfigUntil {

      public static void main(String[] args){

          // 增加请求头
          HashMap<String, String> headers = new HashMap<>();
          headers.put("Content-Type", "application/json; charset=utf-8");

          // 因为要去git获取，还要刷新config-server, 会比较卡，所以一般会要好几秒才能完成
          System.out.println("请耐心等待");

          // 发送post请求
          String result = HttpUtil.createPost("http://localhost:8012/actuator/bus-refresh")
                  .addHeaders(headers).execute().body();

          System.out.println("result" + result);
          System.out.println("refresh 完成");


      }


}
