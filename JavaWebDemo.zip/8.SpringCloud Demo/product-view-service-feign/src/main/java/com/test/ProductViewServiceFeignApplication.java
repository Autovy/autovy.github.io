package com.test;

import brave.sampler.Sampler;
import cn.hutool.core.util.NetUtil;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import java.util.Scanner;

@SpringBootApplication
@EnableEurekaClient // 注册服务中信息注册客户端
@EnableDiscoveryClient
@EnableFeignClients   //表明使用Feign方式
@EnableCircuitBreaker // 共享信息给断路监控器
public class ProductViewServiceFeignApplication {

    public static void main(String[] args) {

        // 增加rabbitmq是否启动判断
        int rabbitMQPort = 5672;
        if(NetUtil.isUsableLocalPort(rabbitMQPort)){
            System.err.printf("未在端口%d发现rabbitMQ服务，请检查", rabbitMQPort);
            System.exit(1);
        }


        // 让用户输入端口号，开启多个服务形成集群
        int port = 0;
        System.out.println("请输入开启服务的端口号：");
        Scanner strpost = new Scanner(System.in);
        port = strpost.nextInt();

        new SpringApplicationBuilder(ProductViewServiceFeignApplication.class)
                .properties("server.port=" + port)
                .run(args);

    }

    /* 配置zipkon:在启动类里配置 Sampler 抽样策略： ALWAYS_SAMPLE 表示持续抽样*/
    @Bean
    public Sampler defaultSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }

}
