package com.test.util;

import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.http.HttpUtil;

// 一个不断访问视图服务的类，以便在监控中观察到现象
// 访问集群的8012和8013端口
public class AccessViewService {

    public static void main(String[] args) {

        while (true){
            ThreadUtil.sleep(1000);
            access(8012);
            access(8013);

        }


    }

    public static void access(int port){

        try{
            String html = HttpUtil.get(String.format("http://127.0.0.1:%d/products", port));
            System.out.println("html length:" + html.length());
        }
        catch (Exception e){
            System.out.printf("%d地址的视图服务无法访问%n", port);
        }

    }


}
