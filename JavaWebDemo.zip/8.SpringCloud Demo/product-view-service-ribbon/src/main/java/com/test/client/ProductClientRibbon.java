package com.test.client;

import com.test.pojo.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;

// Ribbon客户端
@Component
public class ProductClientRibbon {

    @Autowired
    RestTemplate restTemplate;

    public List<Product> list(){

        // 访问数据微服务（未指定端口）
        // 这里的product-data-service既不是域名也不是ip地址，而是数据服务在eureka注册中心的名称
        return restTemplate.getForObject("http://PRODUCT-DATA-SERVICE/products", List.class);

    }





}
