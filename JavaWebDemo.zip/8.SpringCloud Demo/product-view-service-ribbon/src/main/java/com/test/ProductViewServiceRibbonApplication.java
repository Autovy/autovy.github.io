package com.test;

import brave.sampler.Sampler;
import org.hibernate.validator.internal.constraintvalidators.bv.time.future.AbstractFutureEpochBasedValidator;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import java.util.Scanner;
import java.util.concurrent.Future;

@SpringBootApplication
@EnableEurekaClient
@EnableDiscoveryClient // 表示用于发现eureka 注册中心的微服务
public class ProductViewServiceRibbonApplication {
    public static void main(String[] args){
        // 让用户输入端口号，开启多个服务形成集群
        int port = 0;
        System.out.println("请输入开启服务的端口号：");
        Scanner strpost = new Scanner(System.in);
        port = strpost.nextInt();

        // 启动Product-view服务
        new SpringApplicationBuilder(ProductViewServiceRibbonApplication.class)
                .properties("server.port=" + port)
                .run(args);
    }


    // 表示用 restTemplate 这个工具来做负载均衡
    @Bean
    @LoadBalanced
    RestTemplate restTemplate(){
        return new RestTemplate();
    }

    /* 配置zipkon:在启动类里配置 Sampler 抽样策略： ALWAYS_SAMPLE 表示持续抽样*/
    @Bean
    public Sampler defaultSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }


}
