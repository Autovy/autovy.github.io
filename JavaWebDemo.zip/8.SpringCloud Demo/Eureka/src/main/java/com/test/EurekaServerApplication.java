package com.test;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer // 注解标注为Eureka服务
public class EurekaServerApplication {

    public static void main(String[] args) {

        // 设置默认端口
        int port = 8761;
        // 启动EurekaServer管理页面
        new SpringApplicationBuilder(EurekaServerApplication.class)
                .properties("server.port=" + port)
                .run(args);

    }

}
