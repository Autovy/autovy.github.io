package com.test.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.test.pojo.Product;

import java.util.ArrayList;
import java.util.List;

// 服务层（这里不接入dao层，而是提供假数据）
@Service
public class ProductService {

    // 获得配置中的端口号
    @Value("${server.port}")
    String port;

    public List<Product> list(){
        List<Product> ps = new ArrayList<>();
        // 提供假数据，list方法没有对应dao层相应的数据库操作方法
        ps.add(new Product(1,"product a from port:"+port, 50));
        ps.add(new Product(2,"product b from port:"+port, 150));
        ps.add(new Product(3,"product c from port:"+port, 250));
        return ps;

    }

}
