package com.test;

import brave.sampler.Sampler;
import cn.hutool.core.convert.Convert;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import java.util.Scanner;

@SpringBootApplication
@EnableEurekaClient // 服务注册中心客户端，微服务注册
public class ProductDataServiceApplication {

    public static void main(String[] args) {

        // 让用户输入端口号，开启多个服务形成集群
        int port = 0;
        System.out.println("请输入开启服务的端口号：");
        Scanner strpost = new Scanner(System.in);
        port = strpost.nextInt();


        // 启动ProductDataService服务
        new SpringApplicationBuilder(ProductDataServiceApplication.class)
                .properties("server.port=" + port)
                .run(args);


    }

    /* 配置zipkon:在启动类里配置 Sampler 抽样策略： ALWAYS_SAMPLE 表示持续抽样*/
    @Bean
    public Sampler defaultSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }

}
