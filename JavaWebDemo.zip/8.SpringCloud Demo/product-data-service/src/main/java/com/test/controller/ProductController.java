package com.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.test.pojo.Product;
import com.test.service.ProductService;
import java.util.List;

@RestController
public class ProductController {
    // 自动装配服务层
    @Autowired
    ProductService productService;

    // 映射url路径
    @RequestMapping("/products")
    public Object products(){
        // 调用服务层的方法
        List<Product> ps = productService.list();
        return ps;
    }

}
