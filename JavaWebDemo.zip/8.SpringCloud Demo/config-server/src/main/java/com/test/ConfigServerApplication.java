package com.test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient  // 注解标注为Eureka客户端，实现注册
@EnableDiscoveryClient
@EnableConfigServer  // 使用该注解表明该springboot是个配置服务器
public class ConfigServerApplication {
    public static void main(String[] args){
        int port = 8030;

        new SpringApplicationBuilder(ConfigServerApplication.class)
                .properties("server.port="+port)
                .run(args);


    }


}
