import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

// 继承Servlet提供的http处理类
public class HelloServlet extends HttpServlet {

    // 重写doGet方法，处理get请求
    public void doGet(HttpServletRequest request, HttpServletResponse response) {

        // 捕捉http请求异常
        try{
            // 返回响应输出到页面
            response.getWriter().println("<h1>Hello Servlet<h1>");
            response.getWriter().println(new Date().toString());

        }catch (IOException e){
            e.printStackTrace();
        }

    }
}