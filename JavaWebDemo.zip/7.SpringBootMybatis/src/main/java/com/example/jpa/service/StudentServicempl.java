package com.example.jpa.service;

import com.example.jpa.dao.StudentDAO;
import com.example.jpa.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

// 实现接口中具体的操作数据库的方法
@Service
public class StudentServicempl implements StudentService {


    @Autowired
    StudentDAO studentDAO;

    public List<Student> listAll() {
        return studentDAO.findAll();

    }

    public Student get(int id){
        return studentDAO.getById(id);
    }


}
