package com.example.jpa.dao;

import com.example.jpa.pojo.Student;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

// 标注为mybatis的mapper接口
@Mapper
public interface StudentDAO{

    // 使用@Select注解表示调用方法会去执行对应的sql语句
    @Select("select * from student")
    List<Student> findAll();

    @Select("select * from student where id= #{id}")
    Student getById(int id);

}
