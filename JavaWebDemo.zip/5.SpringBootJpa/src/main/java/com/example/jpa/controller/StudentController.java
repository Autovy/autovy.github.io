package com.example.jpa.controller;

import com.example.jpa.dao.StudentDAO;
import com.example.jpa.pojo.Student;
import com.example.jpa.service.StudentServicempl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController // 注解为控制器
public class StudentController {
    // 自动装配service层
    @Autowired
    StudentServicempl studentServicempl;

    @RequestMapping("list")
    public String list(){
        // 存储数据库返回的列表
        List<Student> list = studentServicempl.listAll();

        // 输出的字符串
        String str = "";

        // 遍历列表,获得对象属性的值
        for (Student item: list) {

            // 拼接为字符串输出
            str += item.getId() + "." + item.getName() + "<br>";

        }

        return str;

    }

    @RequestMapping("get")
    public String get(){
        Student student = studentServicempl.get(3);
        return student.getName() + student.getId();

    }

}
