package com.example.jpa.dao;

import com.example.jpa.pojo.Student;
import org.springframework.data.jpa.repository.JpaRepository;

// 继承JpaRepository父接口,提供了一系列操作数据库方法
// 并且提供了泛型<类 , 主键类型>
public interface StudentDAO extends JpaRepository<Student, Integer> {

}
