package com.example.jpa.service;

import com.example.jpa.pojo.Student;

import java.util.List;

// 定义会用到的操作数据库接口
public interface StudentService {


    // 查找所有
    List<Student> listAll();
    // 查找指定id
    Student get(int id);
    // 插入一个对象（一条记录）
    void add(Student s);



}
