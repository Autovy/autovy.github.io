package com.example.jpa.pojo;

import javax.persistence.*;

@Entity // 标记为实体类
@Table(name = "student") // 表明类对应的表名
public class Student {

  // 类的私有属性
  @Id // 标记为主键
  @GeneratedValue(strategy = GenerationType.IDENTITY) // 表明为自增长方式
  @Column(name = "id") // 表明对应的数据库字段名
  private int id;
  @Column(name = "name")
  private String name;
  @Column(name = "age")
  private int age;


  // 提供外界操作属性的方法
  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }


  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }

}
